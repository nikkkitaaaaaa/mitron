import pygame
import random
import sys
import asyncio

async def main():
    pygame.init()
    pygame.mixer.init()

    # ---------------- SCREEN ----------------
    WIDTH, HEIGHT = 500, 700
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Dual Layer Runner - Mobile Ready")

    clock = pygame.time.Clock()

    # ---------------- COLORS ----------------
    ORANGE = (255, 165, 80)
    GROUND_COLOR = (210, 130, 60)
    BUTTON_COLOR = (50, 50, 200)
    BUTTON_HOVER = (80, 80, 255)

    # ---------------- ASSETS ----------------
    # Note: For pygbag, place all assets inside an 'assets' folder
    player_img = pygame.image.load("assets/player.png")
    player_img = pygame.transform.scale(player_img, (50, 50))

    top_bar_img = pygame.image.load("assets/top_bar.png")
    bottom_bar_img = pygame.image.load("assets/bottom_bar.png")

    # ---------------- AUDIO ----------------
    pygame.mixer.music.load("assets/bg_music.ogg")
    pygame.mixer.music.set_volume(0.5)
    # Do NOT start music automatically – browsers block autoplay
    # pygame.mixer.music.play(-1)   <-- removed

    game_over_sound = pygame.mixer.Sound("assets/game_over.ogg")

    # Flag to start music on first user interaction
    music_started = False

    # ---------------- PLAYER ----------------
    player_x = 100
    player_y = HEIGHT // 2 - 25
    velocity = 0
    gravity = 0.6
    jump = -10

    # ---------------- SETTINGS ----------------
    speed = 4
    BAR_WIDTH = 140
    TOP_GAP = 450
    TOP_HEIGHT = 90

    BOTTOM_GAP_MIN = 250
    BOTTOM_GAP_MAX = 600
    BOTTOM_MIN = 120
    BOTTOM_MAX = 420

    score = 0
    font = pygame.font.SysFont(None, 40)
    small_font = pygame.font.SysFont(None, 30)
    game_over = False
    ground_x = 0

    # Restart button rectangle
    restart_rect = pygame.Rect(WIDTH - 110, HEIGHT - 50, 100, 40)

    # ---------------- OBSTACLE LISTS ----------------
    top_bars = []
    bottom_bars = []

    def init_top_bars():
        return [WIDTH + i * TOP_GAP for i in range(4)]

    def init_bottom_bars(num=4):
        bars = []
        x = WIDTH + random.randint(100, 400)
        for i in range(num):
            h = random.randint(BOTTOM_MIN, BOTTOM_MAX)
            bars.append({"x": x, "height": h})
            if i < num - 1:
                x += random.randint(BOTTOM_GAP_MIN, BOTTOM_GAP_MAX)
        return bars

    top_bars = init_top_bars()
    bottom_bars = init_bottom_bars()

    def check_collision(player_rect, top_bars, bottom_bars):
        for tx in top_bars:
            top_rect = pygame.Rect(tx, 0, BAR_WIDTH, TOP_HEIGHT)
            if player_rect.colliderect(top_rect):
                return True
        for bar in bottom_bars:
            bx = bar["x"]
            bh = bar["height"]
            bottom_rect = pygame.Rect(bx, HEIGHT - bh, BAR_WIDTH, bh)
            if player_rect.colliderect(bottom_rect):
                return True
        return False

    def reset_game():
        nonlocal player_y, velocity, score, game_over, top_bars, bottom_bars, music_started
        player_y = HEIGHT // 2 - 25
        velocity = 0
        score = 0
        game_over = False
        top_bars = init_top_bars()
        bottom_bars = init_bottom_bars()
        # Start music on restart (user interaction – button click)
        if not music_started:
            pygame.mixer.music.play(-1)
            music_started = True
        else:
            # Music was stopped at game over, restart it
            pygame.mixer.music.play(-1)

    # ---------------- GAME LOOP (async) ----------------
    running = True
    while running:
        screen.fill(ORANGE)

        # Ground scroll
        pygame.draw.rect(screen, GROUND_COLOR, (ground_x, HEIGHT - 60, WIDTH, 60))
        pygame.draw.rect(screen, GROUND_COLOR, (ground_x + WIDTH, HEIGHT - 60, WIDTH, 60))
        ground_x -= speed
        if ground_x <= -WIDTH:
            ground_x = 0

        # ---------------- EVENT HANDLING ----------------
        mouse_pos = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            # Keyboard controls (desktop)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and not game_over:
                    # Start music on first jump
                    if not music_started:
                        pygame.mixer.music.play(-1)
                        music_started = True
                    velocity = jump
                if event.key == pygame.K_r and game_over:
                    reset_game()

            # Mobile touch / mouse click
            if event.type == pygame.MOUSEBUTTONDOWN:
                # Check if restart button clicked
                if restart_rect.collidepoint(event.pos):
                    reset_game()
                else:
                    # Jump only if game not over and not clicking button
                    if not game_over:
                        # Start music on first jump
                        if not music_started:
                            pygame.mixer.music.play(-1)
                            music_started = True
                        velocity = jump

            # For touch screens (pygbag translates touch to mouse events, but we can also handle FINGERDOWN)
            if event.type == pygame.FINGERDOWN:
                # Convert finger coordinates to screen pixels
                touch_x = event.x * WIDTH
                touch_y = event.y * HEIGHT
                if restart_rect.collidepoint(touch_x, touch_y):
                    reset_game()
                else:
                    if not game_over:
                        # Start music on first jump
                        if not music_started:
                            pygame.mixer.music.play(-1)
                            music_started = True
                        velocity = jump

        # ---------------- GAME LOGIC ----------------
        if not game_over:
            velocity += gravity
            player_y += velocity
            player_rect = pygame.Rect(player_x, player_y, 50, 50)

            # Move bars
            for i in range(len(top_bars)):
                top_bars[i] -= speed
            for bar in bottom_bars:
                bar["x"] -= speed

            # Top bar recycling (score increment)
            if top_bars and top_bars[0] + BAR_WIDTH < 0:
                top_bars.pop(0)
                new_x = top_bars[-1] + TOP_GAP
                top_bars.append(new_x)
                score += 1

            # Bottom bar recycling (random gap & height)
            if bottom_bars and bottom_bars[0]["x"] + BAR_WIDTH < 0:
                bottom_bars.pop(0)
                last_x = bottom_bars[-1]["x"]
                new_gap = random.randint(BOTTOM_GAP_MIN, BOTTOM_GAP_MAX)
                new_x = last_x + new_gap
                new_h = random.randint(BOTTOM_MIN, BOTTOM_MAX)
                bottom_bars.append({"x": new_x, "height": new_h})

            # Collision
            if check_collision(player_rect, top_bars, bottom_bars) or player_y < 0 or player_y > HEIGHT:
                game_over_sound.play()
                pygame.mixer.music.stop()
                game_over = True

        # ---------------- DRAW EVERYTHING ----------------
        # Player
        screen.blit(player_img, (player_x, player_y))

        # Top bars
        for tx in top_bars:
            top_img = pygame.transform.scale(top_bar_img, (BAR_WIDTH, TOP_HEIGHT))
            top_img = pygame.transform.flip(top_img, True, False)
            screen.blit(top_img, (tx, 0))

        # Bottom bars
        for bar in bottom_bars:
            bh = bar["height"]
            bottom_img = pygame.transform.scale(bottom_bar_img, (BAR_WIDTH, bh))
            screen.blit(bottom_img, (bar["x"], HEIGHT - bh))

        # Score
        score_text = font.render(f"Score: {score}", True, (255, 255, 255))
        screen.blit(score_text, (20, 20))

        # Restart button (visible always, but only functional when game_over or anytime)
        button_color = BUTTON_HOVER if restart_rect.collidepoint(mouse_pos) else BUTTON_COLOR
        pygame.draw.rect(screen, button_color, restart_rect, border_radius=10)
        restart_text = small_font.render("Restart", True, (255, 255, 255))
        text_rect = restart_text.get_rect(center=restart_rect.center)
        screen.blit(restart_text, text_rect)

        # Game over message
        if game_over:
            over_text = font.render("GAME OVER", True, (255, 0, 0))
            screen.blit(over_text, (WIDTH//2 - over_text.get_width()//2, HEIGHT//2 - 40))
            tap_text = small_font.render("Tap Restart or press R", True, (255, 255, 255))
            screen.blit(tap_text, (WIDTH//2 - tap_text.get_width()//2, HEIGHT//2 + 10))

        pygame.display.update()
        await asyncio.sleep(0)
        clock.tick(60)

    pygame.quit()
    sys.exit()

asyncio.run(main())