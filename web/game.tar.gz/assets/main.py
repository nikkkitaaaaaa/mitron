import pygame
import random
import sys
import asyncio

# ---------- ASYNC SETUP FOR PYGBAG ----------
async def main():
    pygame.init()
    pygame.mixer.init()

    # ---------------- SCREEN ----------------
    WIDTH, HEIGHT = 500, 700
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Dual Layer Runner - Web")

    clock = pygame.time.Clock()

    # ---------------- COLORS ----------------
    ORANGE = (255, 165, 80)
    GROUND_COLOR = (210, 130, 60)

    # ---------------- ASSETS (load asynchronously) ----------------
    # For Pygbag, we must use 'await' and load from the 'assets' folder
    # Place player.png, top_bar.png, bottom_bar.png, bg_music.mp3, game_over.wav inside an 'assets' folder
    player_img = pygame.image.load("assets/player.png")
    player_img = pygame.transform.scale(player_img, (50, 50))

    top_bar_img = pygame.image.load("assets/top_bar.png")
    bottom_bar_img = pygame.image.load("assets/bottom_bar.png")

    # ---------------- AUDIO ----------------
    pygame.mixer.music.load("assets/bg_music.ogg")
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play(-1)

    game_over_sound = pygame.mixer.Sound("assets/game_over.ogg")

    # ---------------- PLAYER ----------------
    player_x = 100
    player_y = HEIGHT // 2 - 25
    velocity = 0
    gravity = 0.6
    jump = -10

    # ---------------- SETTINGS ----------------
    speed = 4
    BAR_WIDTH = 140
    TOP_GAP = 450
    TOP_HEIGHT = 90

    BOTTOM_GAP_MIN = 250
    BOTTOM_GAP_MAX = 600
    BOTTOM_MIN = 120
    BOTTOM_MAX = 420

    score = 0
    font = pygame.font.SysFont(None, 40)
    game_over = False
    ground_x = 0

    # ---------------- OBSTACLE LISTS ----------------
    top_bars = []
    bottom_bars = []

    def init_top_bars():
        return [WIDTH + i * TOP_GAP for i in range(4)]

    def init_bottom_bars(num=4):
        bars = []
        x = WIDTH + random.randint(100, 400)
        for i in range(num):
            h = random.randint(BOTTOM_MIN, BOTTOM_MAX)
            bars.append({"x": x, "height": h})
            if i < num - 1:
                x += random.randint(BOTTOM_GAP_MIN, BOTTOM_GAP_MAX)
        return bars

    top_bars = init_top_bars()
    bottom_bars = init_bottom_bars()

    def check_collision(player_rect, top_bars, bottom_bars):
        for tx in top_bars:
            top_rect = pygame.Rect(tx, 0, BAR_WIDTH, TOP_HEIGHT)
            if player_rect.colliderect(top_rect):
                return True
        for bar in bottom_bars:
            bx = bar["x"]
            bh = bar["height"]
            bottom_rect = pygame.Rect(bx, HEIGHT - bh, BAR_WIDTH, bh)
            if player_rect.colliderect(bottom_rect):
                return True
        return False

    # ---------------- GAME LOOP (async) ----------------
    running = True
    while running:
        screen.fill(ORANGE)

        # Ground scroll
        pygame.draw.rect(screen, GROUND_COLOR, (ground_x, HEIGHT - 60, WIDTH, 60))
        pygame.draw.rect(screen, GROUND_COLOR, (ground_x + WIDTH, HEIGHT - 60, WIDTH, 60))
        ground_x -= speed
        if ground_x <= -WIDTH:
            ground_x = 0

        # Events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and not game_over:
                    velocity = jump
                if event.key == pygame.K_r and game_over:
                    player_y = HEIGHT // 2 - 25
                    velocity = 0
                    top_bars = init_top_bars()
                    bottom_bars = init_bottom_bars()
                    score = 0
                    game_over = False
                    pygame.mixer.music.play(-1)

        if not game_over:
            velocity += gravity
            player_y += velocity
            player_rect = pygame.Rect(player_x, player_y, 50, 50)

            # Move bars
            for i in range(len(top_bars)):
                top_bars[i] -= speed
            for bar in bottom_bars:
                bar["x"] -= speed

            # Top bar recycling (score increment)
            if top_bars and top_bars[0] + BAR_WIDTH < 0:
                top_bars.pop(0)
                new_x = top_bars[-1] + TOP_GAP
                top_bars.append(new_x)
                score += 1

            # Bottom bar recycling (random gap & height)
            if bottom_bars and bottom_bars[0]["x"] + BAR_WIDTH < 0:
                bottom_bars.pop(0)
                last_x = bottom_bars[-1]["x"]
                new_gap = random.randint(BOTTOM_GAP_MIN, BOTTOM_GAP_MAX)
                new_x = last_x + new_gap
                new_h = random.randint(BOTTOM_MIN, BOTTOM_MAX)
                bottom_bars.append({"x": new_x, "height": new_h})

            # Collision
            if check_collision(player_rect, top_bars, bottom_bars) or player_y < 0 or player_y > HEIGHT:
                game_over_sound.play()
                pygame.mixer.music.stop()
                game_over = True

        # Drawing
        screen.blit(player_img, (player_x, player_y))
        for tx in top_bars:
            top_img = pygame.transform.scale(top_bar_img, (BAR_WIDTH, TOP_HEIGHT))
            top_img = pygame.transform.flip(top_img, True, False)
            screen.blit(top_img, (tx, 0))
        for bar in bottom_bars:
            bh = bar["height"]
            bottom_img = pygame.transform.scale(bottom_bar_img, (BAR_WIDTH, bh))
            screen.blit(bottom_img, (bar["x"], HEIGHT - bh))

        score_text = font.render(f"Score: {score}", True, (255, 255, 255))
        screen.blit(score_text, (20, 20))

        if game_over:
            over_text = font.render("GAME OVER (Press R)", True, (255, 0, 0))
            screen.blit(over_text, (80, HEIGHT // 2))

        pygame.display.update()
        await asyncio.sleep(0)   # Required for Pygbag
        clock.tick(60)           # Still works, but async sleep is the key

    pygame.quit()
    sys.exit()

# ---------------- PYGBAG ENTRY POINT ----------------
asyncio.run(main())